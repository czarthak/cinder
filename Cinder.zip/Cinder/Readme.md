To run Cinder:
Step 1: Unzip the zip file 
Step 2: Open the Cinder Folder go to cinder_client and run the following commands:
npm install
npm start
Step 3: Parallel to the client server ran above, go to the cinder_server directory and run:
npm install 
npm start
This will start both the front-end and the back-end server
